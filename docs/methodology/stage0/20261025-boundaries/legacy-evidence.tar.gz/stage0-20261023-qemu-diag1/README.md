# Stage 0 QEMU diagnostic run 1

**Captured:** 2026-10-23 (Asia/Ho_Chi_Minh)  
**HAVEN base revision:** `f775304ce9443dc9861ba1880e4208c7ae19b314`  
**Working change:** diagnostic-only print of ESR/FAR/ELR in
`src/core/exc/el2_exceptions.c` before the existing fatal marker.  
**Target:** same QEMU `virt` configuration as the preceding baseline.  
**Result:** reproduced and localized the synchronous exception to the PSCI
`HVC #0` instruction in `hv_arch_psci_cpu_on()`.

## Observation

The UART output contains:

```text
EL2 FATAL: ESR=0x5a000000 FAR=0x0 ELR=0x800000e8
!EL2
```

`ESR[31:26]` is `0x16`, the HVC instruction exception class. `ELR` is the
address immediately after the `hvc #0` instruction: `aarch64-linux-gnu-objdump`
shows `hvc #0` at `0x800000e4` and `cbz` at `0x800000e8` inside
`hv_arch_psci_cpu_on()` in `arch/arm64/boot.S`. Thus the run reaches the
PSCI `CPU_ON` call while HAVEN is executing at EL2 and the HVC returns as a
synchronous exception to HAVEN's EL2 vector. Arm documents that HVC targets
EL2, and an exception cannot reduce privilege; an HVC issued at EL2 is therefore
taken at the current EL. See the [Armv8-A Instruction Set Architecture guide](https://developer.arm.com/-/media/Arm%20Developer%20Community/PDF/Learn%20the%20Architecture/Armv8-A%20Instruction%20Set%20Architecture.pdf),
section 12.

This localizes why `hv_fatal_exception()` runs. It does not establish which
PSCI conduit or firmware setup should replace the current call for QEMU and
each physical platform. The source comment that “QEMU virt uses HVC” describes
the conduit for a lower-EL operating system and does not justify issuing HVC
from HAVEN at EL2. The default QEMU loader flow used here starts HAVEN directly
at EL2; it does not provide an observed higher-level PSCI handler.

The official [Trusted Firmware-A QEMU virt platform guide](https://trustedfirmware-a.readthedocs.io/en/v2.8.48/plat/qemu.html)
documents an alternative test boot chain: TF-A supplies EL3 firmware, BL31
provides runtime services including PSCI, and the QEMU-generated FDT is updated
with a PSCI node and CPU enable methods. TF-A's [current porting guide](https://trustedfirmware-a.readthedocs.io/en/latest/porting-guide.html)
also describes BL31 as resident at EL3 and providing PSCI runtime services.
This is a candidate for a separate QEMU baseline run, not evidence that the
existing direct-load setup or any target-board firmware has that service. The
documented TF-A QEMU guide is for TF-A v2.8.48; check the current TF-A/QEMU
instructions and exact handoff before using binaries or assuming compatibility.

No partition guest marker appeared. QEMU was terminated by the five-second
diagnostic harness after the fatal handler remained in its halt loop; code 124
is the harness timeout indicator.

## Build and captured files

The diagnostic build was incremental in `/private/tmp/haven-stage0-qemu` and
completed two Ninja steps. Linker warnings about the RWX LOAD segment and
discarded GNU build-id note remain.

| File | SHA-256 |
| --- | --- |
| `qemu-uart-diag1.log` | `145ec8a499f7f270387d2ec9fa15b1599da4c2397b580678df27e3e64a8c5d5d` |
| `qemu-console-diag1.log` | `d94085412ee2346f82a5b927f8a65db9f67cc35f6f2ae1b3c51325100c3d194c` |
| `haven.bin` | `1c4765004c4ece860ee55a285b33d80483078e0541c35bb0a54a6175c8dff7a2` |
| `guest_a.bin` | `00d4c4dd4cb94e6bba6b89c9c0b0bc4c962c45bcd39eba5b268ae722b9b2eeea` |
| `guest_b.bin` | `616671c42e10a6571169f6c96a15cb9581dade662909955c13f0945185c6fafb` |

## Next decision

Do not change the PSCI call path until the intended QEMU and board firmware
contracts are established. The next research/audit question is whether the
baseline should provide an EL3 PSCI service and use its supported conduit, or
whether the QEMU platform needs a different secondary-CPU startup arrangement.
These alternatives affect platform binding and must be evaluated against the
physical firmware handoff when boards become available.
