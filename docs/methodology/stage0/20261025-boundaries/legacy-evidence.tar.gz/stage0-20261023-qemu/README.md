# Stage 0 QEMU baseline

**Captured:** 2026-10-23 (Asia/Ho_Chi_Minh)  
**HAVEN revision:** `f775304ce9443dc9861ba1880e4208c7ae19b314`  
**Classification:** EXPERIMENT  
**Target:** QEMU `virt`, AArch64, 4 CPUs, 2 GiB, GICv3, SMMUv3  
**Result:** failed to reach either guest; fatal EL2 exception after stage-2 activation.

This is QEMU evidence only. No physical board was available and this result says
nothing about physical board behavior.

## Environment and build

- Host: macOS 27.0.1 (build 26A434), Apple Silicon ARM64.
- QEMU: `qemu-system-aarch64` 11.1.2.
- CMake: 4.4.4; Ninja generator.
- Cross compiler: `aarch64-linux-gnu-gcc` 15.2.0.
- Build command: `cmake -S <haven> -B /private/tmp/haven-stage0-qemu -G Ninja -DCMAKE_TOOLCHAIN_FILE=<haven>/cmake/arm64.cmake -DPLATFORM=qemu-virt -DCMAKE_BUILD_TYPE=MinSizeRel && cmake --build /private/tmp/haven-stage0-qemu --parallel 4`.
- The checked-in `arm64-qemu` preset points at `haven/build`, whose existing
  CMake cache belongs to `/Users/trongphucnguyen/Documents/haven`. The preset
  therefore failed with a source-directory mismatch. That cache and its old
  outputs were left untouched; this run used a new temporary build directory.
- The fresh build completed all 32 build steps. The linker warned that
  `haven.elf`, `guest_a.elf`, and `guest_b.elf` each have an RWX LOAD segment;
  it also warned that the GNU build-id note was discarded.

## Run and observed result

The repository smoke script is hard-coded to `build/haven.bin`. To avoid using
the stale binary in `haven/build`, the same QEMU machine and loader setup was
run against the fresh temporary build. UART and console output were captured in
this directory. QEMU was terminated by the 30-second harness timeout after
remaining in the fatal handler; return code 124 is the harness timeout result,
not a natural QEMU exit status.

Observed UART progression:

1. `Haven hypervisor starting` and ARM feature checks passed.
2. HAVEN printed that it mapped partition A and B, assigned the A IRQ, set both
   budgets, and enabled stage 2 for partition A.
3. HAVEN printed `!EL2`.
4. Neither `PARTITION_A:` nor `PARTITION_B:` appeared.

This run does not pass the guest boot smoke criterion. It shows execution
reached the partition handoff area and then entered `hv_fatal_exception()`.
That handler in `src/core/exc/el2_exceptions.c` deliberately discards ESR, FAR,
ELR, and SP before printing `!EL2`, so the exact fault cause is not observable
from this log. Do not guess the fault or soften the result to a pass.

## Captured files

| File | Purpose | SHA-256 |
| --- | --- | --- |
| `qemu-uart.log` | Raw guest/EL2 UART capture | `cc96ef257b8c9b7d6bb310207fc76c84180fb78316f15417411530254f50b0f7` |
| `qemu-console.log` | QEMU process output | `4410cd900ad41eab0d32899f075e91df42e630727203d581058f1499510e904b` |
| `haven.bin` | Hypervisor image used for the run | `a226395517a5691825c4a1beab898ce532c5512cfab59a65186be3253ded0ed9` |
| `guest_a.bin` | Partition A image used for the run | `00d4c4dd4cb94e6bba6b89c9c0b0bc4c962c45bcd39eba5b268ae722b9b2eeea` |
| `guest_b.bin` | Partition B image used for the run | `616671c42e10a6571169f6c96a15cb9581dade662909955c13f0945185c6fafb` |

## Follow-up

The next HAVEN task is a focused BUGFIX/AUDIT to expose syndrome registers in a
safe diagnostic record and identify why the EL2 fatal path fires after
`hv_arch_stage2_enable()` / during partition launch. Preserve this failed run;
rerun only after changing the image or runner, and give each run a new evidence
directory. No source code was changed for this experiment.
