# Stage 0 TF-A QEMU guest run 1

**Captured:** 2026-10-23 (Asia/Ho_Chi_Minh)  
**HAVEN base revision:** `f775304ce9443dc9861ba1880e4208c7ae19b314`  
**TF-A tag / commit:** `v2.15.0` / `da738d5eae93af342fdc4995dd3c05acb4c9d757`  
**Result:** Partition A booted, its deliberate cross-partition read generated a
stage-2 fault at IPA `0x60000000`, and A resumed to print its post-fault marker.

## Configuration and provenance

TF-A source was cloned from the official
[ARM-software/arm-trusted-firmware repository](https://github.com/ARM-software/arm-trusted-firmware)
at tag `v2.15.0`, commit `da738d5eae93af342fdc4995dd3c05acb4c9d757`. TF-A's
[QEMU virt guide](https://trustedfirmware-a.readthedocs.io/en/latest/plat/qemu.html)
describes its BL1/BL2/BL31 boot flow and a preloaded BL33 option. The build
used `PLAT=qemu`, `QEMU_USE_GIC_DRIVER=QEMU_GICV3`,
`PRELOADED_BL33_BASE=0x80000000`, `DEBUG=0`, `LOG_LEVEL=20`, and
`CROSS_COMPILE=aarch64-linux-gnu-`, producing BL1, BL2, and BL31. The TF-A
`fip` target was not required for the documented semihosting flow.

A clean temporary copy of HAVEN was built with only the PSCI instruction in
`arch/arm64/boot.S` changed from `hvc #0` to `smc #0`. No tracked PSCI source
change was made. The experiment used the existing diagnostic-only tracked
change to the fatal exception print. Both guest images were explicitly loaded
at the physical addresses expected by HAVEN:

- HAVEN BL33: `0x80000000`
- Guest A: `0x80800000`
- Guest B: `0xa0800000`

QEMU 11.1.2 configuration: `virt,secure=on,virtualization=on,gic-version=3,
iommu=smmuv3`, Cortex-A72, 4 CPUs, 2 GiB RAM, TF-A BL1 via `-bios`, native
semihosting, and the three raw-image loader devices. The bounded runner stopped
QEMU after four seconds. Its console capture is empty; UART output is in
`qemu-uart.log`.

## Observed result

TF-A BL1, BL2, and BL31 started, then handed control to HAVEN. HAVEN initialized
its QEMU GICv3 path, configured both stage-2 maps, and called PSCI `CPU_ON` for
CPU 2. After the temporary SMC change, that call returned success and HAVEN
continued to its partition-A ERET path.

Partition A printed:

```text
PARTITION_A: Hello from partition A (EL1 guest)
HAVEN: Denied stage-2 violation IPA=0x60000000 FAR=0x60000000 ESR=0x93c08006
PARTITION_A: Post-fault check OK
```

This is a virtual QEMU observation that the guest-A path executed, an access
outside A's mapped IPA range faulted, and the existing handler advanced past
the faulting load so A continued. The console does not establish that CPU 2
executed the secondary initialization/guest-B entry; the success return and
primary-core message only establish that PSCI accepted the request. Add an
explicit secondary-entry observation in a separate follow-up if B execution is
needed for the baseline. No DMA/SMMU isolation, physical firmware behavior, or
board support is established by this run.

The earlier setup trial in
[`stage0-20261023-tfa-qemu`](../stage0-20261023-tfa-qemu/README.md) omitted the
guest loader devices and is retained only to document that correction.

## SHA-256

| File | SHA-256 |
| --- | --- |
| `qemu-uart.log` | `7cdbf9d872af368b547351a44d5362168671056d3444b304a3fcb49f369f1bb5` |
| `qemu-console.log` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `bl1.bin` | `36e92729ffd0d3e7499dd0648d273f3cfa0bab51b07b8cce52c56465870c4ec7` |
| `bl2.bin` | `92b70dc998bf2b8cc2290c523b2d31b84926ae23ae554ce8c8252d0661046d1d` |
| `bl31.bin` | `588a7e29bad277db457721cbf91f87358356418c0717d7178844f64c38e92076` |
| `haven.bin` | `da49b8ae191202c03fa94ddb664843e83fd8985999d9f5172d816fbd1f4526d8` |
| `guest_a.bin` | `00d4c4dd4cb94e6bba6b89c9c0b0bc4c962c45bcd39eba5b268ae722b9b2eeea` |
| `guest_b.bin` | `616671c42e10a6571169f6c96a15cb9581dade662909955c13f0945185c6fafb` |
