# Stage 0 initial TF-A QEMU setup trial (guest images omitted)

**Captured:** 2026-10-23 (Asia/Ho_Chi_Minh)  
**HAVEN base revision:** `f775304ce9443dc9861ba1880e4208c7ae19b314`  
**TF-A tag / commit:** `v2.15.0` / `da738d5eae93af342fdc4995dd3c05acb4c9d757`  
**Result:** TF-A booted HAVEN at EL2; the temporary SMC PSCI call returned
success. This first run accidentally omitted the `guest_a.bin` and
`guest_b.bin` loader devices. Its high-volume stage-2 output is therefore not
valid evidence about guest behavior. The corrected run is recorded in
[`stage0-20261023-tfa-qemu-guest1`](../stage0-20261023-tfa-qemu-guest1/README.md).

## Setup

The official TF-A repository was cloned to `/private/tmp` at the pinned tag.
Its QEMU guide describes the BL1/BL2/BL31 semihosting flow and setting
`PRELOADED_BL33_BASE` for a preloaded non-secure image. The local build used
`PLAT=qemu`, `QEMU_USE_GIC_DRIVER=QEMU_GICV3`,
`PRELOADED_BL33_BASE=0x80000000`, `DEBUG=0`, `LOG_LEVEL=20`, and
`CROSS_COMPILE=aarch64-linux-gnu-`. It completed `all`, producing BL1, BL2,
and BL31. TF-A's optional `fip` target was not needed for this semihosting flow;
the earlier attempt to build it stopped because the system OpenSSL headers were
not found at TF-A's default `/usr` path.

The host's default `make` (GNU Make 3.81) could not parse this TF-A revision.
The build used Homebrew GNU Make 4.4.1 and a temporary `sed` shim pointing to
Homebrew GNU sed because TF-A's helper uses GNU sed syntax. No repository
dependencies or system packages were installed.

HAVEN was copied to `/private/tmp/haven-tfa-smc`, and only that temporary copy's
`arch/arm64/boot.S` changed the PSCI instruction from `hvc #0` to `smc #0`.
The temporary build used the QEMU platform, four Cortex-A72 CPUs, GICv3 and
the same 2 GiB QEMU memory configuration. The tracked HAVEN source was not
changed for this experiment; its existing diagnostic-only exception print is
the sole tracked modification.

QEMU was launched with `virt,secure=on,virtualization=on,gic-version=3,
iommu=smmuv3`, `-bios bl1.bin`, native semihosting enabled, and the HAVEN raw
image preloaded at `0x80000000`. The process was stopped manually after the
UART log began flooding with stage-2 violations.

## Observation

The log shows TF-A BL1, BL2, and BL31 starting, then HAVEN entering at EL2.
HAVEN printed `CPU 2 woken for partition B`, so the temporary SMC PSCI call
returned success through this QEMU BL31 configuration. It then printed
`ERET -> partition A entry IPA=0x40000000`.

The 54,533 stage-2 violation lines (3,836,517 bytes), starting at `FAR=0x200`,
came from this setup trial with no guest images loaded at their configured
physical addresses. Do not use that output to characterize HAVEN's guest
translation, and do not treat the empty guest markers as an implementation
failure. The retained log and binaries document the setup mistake and support
reproducibility of the corrected run only when considered alongside the new
evidence record.

## SHA-256

| File | SHA-256 |
| --- | --- |
| `qemu-uart.log` | `71c7e4e6aca15522a8d3d110ff25653255a238b146ac76c2fe49f90dc57450f4` |
| `bl1.bin` | `36e92729ffd0d3e7499dd0648d273f3cfa0bab51b07b8cce52c56465870c4ec7` |
| `bl2.bin` | `92b70dc998bf2b8cc2290c523b2d31b84926ae23ae554ce8c8252d0661046d1d` |
| `bl31.bin` | `588a7e29bad277db457721cbf91f87358356418c0717d7178844f64c38e92076` |
| `haven.bin` | `e900ec8d3a51884306abd3a6b69025d1901f400487ba1bb5de9cf1e1ccca8a54` |
| `guest_a.bin` | `00d4c4dd4cb94e6bba6b89c9c0b0bc4c962c45bcd39eba5b268ae722b9b2eeea` |
| `guest_b.bin` | `616671c42e10a6571169f6c96a15cb9581dade662909955c13f0945185c6fafb` |
