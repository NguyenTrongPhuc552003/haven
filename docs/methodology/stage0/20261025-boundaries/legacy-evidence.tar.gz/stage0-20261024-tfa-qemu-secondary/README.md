# Stage 0 QEMU secondary-core diagnostic

**Captured:** 2026-10-24 (Asia/Ho_Chi_Minh)  
**HAVEN base revision:** `f775304ce9443dc9861ba1880e4208c7ae19b314`  
**Firmware/QEMU:** TF-A `v2.15.0`, commit
`da738d5eae93af342fdc4995dd3c05acb4c9d757`; QEMU 11.1.2  
**Classification:** AUDIT / EXPERIMENT; all code changes described here were
made in `/private/tmp` copies only.

## Question

Does the TF-A PSCI-backed QEMU run actually reach guest B on CPU 2, and which
secondary-core setup is needed for its stage-2 exceptions to reach HAVEN?

## Controlled setup

The firmware and QEMU configuration match the
[corrected guest-A run](../stage0-20261023-tfa-qemu-guest1/README.md). A clean
temporary HAVEN copy changed PSCI HVC to SMC. The guest-B diagnostic image was
modified only for this probe: it reduces `TASK_SPIN_ITERS` from `0x100000` to
`0x400` and reads partition A's IPA immediately after stack setup, before its
workload loops. The temporary exception handler logs stage-2 faults only on
CPU 2, so the output does not mix CPU 0's expected partition-A fault into the
secondary-core observation.

Two secondary-core variants were compared:

1. **Exception vectors only:** call `hv_install_vectors()` on CPU 2 before
   enabling partition B's stage-2 table.
2. **Full CPU initialization:** call `hv_arch_cpu_init()` on CPU 2 before
   enabling partition B's stage-2 table.

A third run narrowed the successful setup to a tested subset: install vectors,
write `HCR_EL2 = HCR_VM | HCR_RW`, write `VTCR_EL2 = VTCR_HAVEN_DEFAULT`,
then use the existing `hv_arch_stage2_enable()` to install the partition's
VTTBR. Other `hv_arch_cpu_init()` writes were omitted in this variant.

In both variants, guest A/B binaries were loaded at `0x80800000` and
`0xa0800000`; QEMU ran for a four-second bound. No tracked HAVEN or guest source
was changed.

## Observations

With vectors only, QEMU logged `EL2 FATAL: ESR=0x3a000000 FAR=0x0
ELR=0x60000000` and `!EL2`. The run did not log a CPU 2 stage-2 denial from
guest B.

With full `hv_arch_cpu_init()` on CPU 2, the run logged two CPU 2 stage-2
violations at `IPA=0x40000000 FAR=0x40000000`, with ELRs `0x60000010` and
`0x60000028`. The guest-B diagnostic load is the first; the second is guest B's
existing cross-partition load after its shortened loops. This is evidence that
CPU 2 entered and executed guest-B instructions, and that the handler resumed
after both denied loads. The output also retained partition A's greeting and
post-fault marker.

The narrowed subset produced the same two CPU 2 denials and partition-A
markers. Therefore, vectors + `HCR_VM | HCR_RW` + the QEMU `VTCR` value, with
VTTBR installed by the existing stage-2 activation, were sufficient for this
specific guest-entry and denied-memory-access path. This is the minimum subset
tested so far, not proof that each item is individually necessary or that it
can replace the full initializer. It does not exercise IRQ routing, virtual
interrupt injection, timer behavior, cache state, or guest SMC handling.

The source declares `hv_arch_cpu_init()` must run once per CPU, and primary
`haven_init()` invokes it. The current `partition_b_secondary_cpu_init()` only
enables B's stage-2 table before ERET; it does not invoke the CPU initializer.
The controlled comparison supports the hypothesis that incomplete per-CPU EL2
initialization is why B did not produce a handled stage-2 fault in the prior
run. Since the full initializer changes several EL2 registers, this experiment
does not isolate which register(s) are individually necessary. Review the full
per-core startup contract, including the GIC virtual interface, before making
a tracked fix.

This remains QEMU-only evidence. It does not establish physical firmware
behavior, DMA/SMMU isolation, or support for any named board. The temporary
guest workload is diagnostic and is not a performance measurement.

## Captured files and SHA-256

| Variant | File | SHA-256 |
| --- | --- | --- |
| Vectors only | `vector-only/qemu-uart.log` | `36072954f461ca9ac6a1cdae808b01c113ca208cbed2f50cb18bcf76c9e6dfd7` |
| Vectors only | `vector-only/haven.bin` | `fef199c72574930b62608e6ae7f365b0c1a01b8b1579cefae118071c1d9abb5e` |
| Vectors only | `vector-only/guest_b-diagnostic.bin` | `d55ccddc7eb563f6a6fb37d5e39277e76881dcc0d219f3f6df0075cf8747d1a1` |
| Full CPU init | `full-cpu-init/qemu-uart.log` | `11d4b408854df67422165301885045fec98605a08e4309081408d4caae31e374` |
| Full CPU init | `full-cpu-init/haven.bin` | `21df45c566a081604b72037511bb58f72d93557cbb0e6faf35f6380fc208bcb3` |
| Full CPU init | `full-cpu-init/guest_b-diagnostic.bin` | `d55ccddc7eb563f6a6fb37d5e39277e76881dcc0d219f3f6df0075cf8747d1a1` |
| Narrowed subset | `minimal-s2/qemu-uart.log` | `11d4b408854df67422165301885045fec98605a08e4309081408d4caae31e374` |
| Narrowed subset | `minimal-s2/haven.bin` | `9f6e4118f7b780795a70d5631b9d9399777c74e9e6f6c1365f532f3e38bf73be` |
| Narrowed subset | `minimal-s2/guest_b-diagnostic.bin` | `d55ccddc7eb563f6a6fb37d5e39277e76881dcc0d219f3f6df0075cf8747d1a1` |
