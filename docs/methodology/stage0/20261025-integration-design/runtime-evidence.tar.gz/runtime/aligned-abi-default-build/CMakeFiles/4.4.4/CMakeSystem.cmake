set(CMAKE_HOST_SYSTEM "Darwin-27.0.0")
set(CMAKE_HOST_SYSTEM_NAME "Darwin")
set(CMAKE_HOST_SYSTEM_VERSION "27.0.0")
set(CMAKE_HOST_SYSTEM_PROCESSOR "arm64")

include("/private/tmp/haven-stage0-integration-runtime-approved/aligned-abi-default-source/cmake/arm64.cmake")

set(CMAKE_SYSTEM "Generic")
set(CMAKE_SYSTEM_NAME "Generic")
set(CMAKE_SYSTEM_VERSION "")
set(CMAKE_SYSTEM_PROCESSOR "aarch64")

set(CMAKE_CROSSCOMPILING "TRUE")

set(CMAKE_SYSTEM_LOADED 1)
