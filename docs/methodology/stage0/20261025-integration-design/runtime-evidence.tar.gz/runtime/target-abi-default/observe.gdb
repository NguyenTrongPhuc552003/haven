set pagination off
set confirm off
set remotetimeout 3
target remote /private/tmp/haven-stage0-integration-runtime-approved/target-abi-default.sock
hbreak _start
continue
printf "CHECKPOINT PRIMARY_ENTRY\n"
info all-registers
delete breakpoints
hbreak hv_fatal_exception
hbreak partitions_launch
continue
printf "CHECKPOINT PRIMARY_POST_INIT_OR_FATAL\n"
info all-registers
detach
quit
